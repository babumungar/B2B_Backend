package com.stg.b2b.order;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class OrderServiceTest {


	@Test
	void testGetAllOrders() {
		assertEquals(1,1);
	}

}
