package com.stg.b2b;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class B2bApplicationTest {
}
