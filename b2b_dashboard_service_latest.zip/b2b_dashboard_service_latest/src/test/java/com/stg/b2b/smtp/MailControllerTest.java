package com.stg.b2b.smtp;

import org.junit.jupiter.api.Test;

public class MailControllerTest {
    @Test
    public void testSendMail(){

    }
}
