package com.stg.b2b.dashboard.dto;

public interface InterviewTypeDto {
    Integer getInterviewId();
}
