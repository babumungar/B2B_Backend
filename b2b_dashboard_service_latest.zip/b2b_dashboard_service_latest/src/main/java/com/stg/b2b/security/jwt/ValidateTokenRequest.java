package com.stg.b2b.security.jwt;

import lombok.Data;

@Data
public class ValidateTokenRequest {
    private String token;
}
