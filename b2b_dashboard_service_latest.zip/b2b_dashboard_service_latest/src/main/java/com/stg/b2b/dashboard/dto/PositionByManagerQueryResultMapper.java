package com.stg.b2b.dashboard.dto;




public interface PositionByManagerQueryResultMapper {

    String getManagerColumn();


    int getNoOfPositions();

}
