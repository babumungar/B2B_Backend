package com.stg.b2b.dashboard.dto;

public interface PositionsByMonthMapper {

    Integer getYear();
    String getMonth();
    Integer getPositionsCount();


}
