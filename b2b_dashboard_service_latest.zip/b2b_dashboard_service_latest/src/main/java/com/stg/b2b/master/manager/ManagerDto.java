package com.stg.b2b.master.manager;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ManagerDto {

    Integer managerId;

    String ll2Manager;

    String ll3Manager;

    String ll4Manager;

    String ll5Manager;

    String ll6Manager;

}
