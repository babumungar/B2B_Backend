package com.stg.b2b.hrreports.dto;

;


public interface PositionByMonthDto {

    String getMonth();

    Integer getOrderNo();

    Integer getOrdNoOfPositions();
}
