package com.stg.b2b.dashboard.dto;

public interface PositionBySkillGroupDTO {

    String getSkillGroup();

    Integer getSumOFNoOfPositions();
}
