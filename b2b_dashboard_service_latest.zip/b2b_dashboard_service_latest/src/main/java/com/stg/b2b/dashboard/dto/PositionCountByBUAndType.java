package com.stg.b2b.dashboard.dto;

public interface PositionCountByBUAndType {

    String getBusinessLineName();

    String getPositionType();
    int getNoOfVacancy();
}
