package com.stg.b2b.dashboard.dto;

public interface PositionsTypeDTO {

    String getPositionType();

    int getNoOfPositions();


}
