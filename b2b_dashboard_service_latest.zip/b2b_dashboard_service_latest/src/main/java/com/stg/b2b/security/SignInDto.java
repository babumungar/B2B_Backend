package com.stg.b2b.security;

import lombok.Data;

@Data
public class SignInDto {
    private String username;
    private  String password;
}
