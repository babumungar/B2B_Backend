package com.stg.b2b.master.businessunit;

public interface ProductLineDto {
    Integer getProductLineId();
    String getProductLineName();
}
