package com.stg.b2b.dashboard.dto;

import java.sql.Date;

public interface CountWDateDto {
    Date getDate();
    Integer getCount();
}
