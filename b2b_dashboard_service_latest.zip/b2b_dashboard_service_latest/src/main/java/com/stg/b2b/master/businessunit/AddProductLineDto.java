package com.stg.b2b.master.businessunit;

import lombok.Data;

@Data
public class AddProductLineDto {
    String buName;
    String productLineName;
}
